import React, { useState } from 'react';
import { cardapioCompleto } from '../data/mock';
import '../styles/Cardapio.css';

const Cardapio = () => {
  const [categoriaAtiva, setCategoriaAtiva] = useState('hamburguers');

  const categorias = [
    { id: 'hamburguers', label: 'Hambúrguers', items: cardapioCompleto.hamburguers },
    { id: 'carnes', label: 'Carnes Grelhadas', items: cardapioCompleto.carnes },
    { id: 'frutosDoMar', label: 'Frutos do Mar', items: cardapioCompleto.frutosDoMar },
    { id: 'acompanhamentos', label: 'Acompanhamentos', items: cardapioCompleto.acompanhamentos },
    { id: 'sobremesas', label: 'Sobremesas', items: cardapioCompleto.sobremesas },
    { id: 'bebidas', label: 'Bebidas', items: cardapioCompleto.bebidas }
  ];

  const categoriaAtual = categorias.find(cat => cat.id === categoriaAtiva);

  return (
    <div className="cardapio-page">
      <div className="page-hero">
        <h1 className="page-title">Nosso Cardápio</h1>
        <p className="page-subtitle">
          Descubra nossos pratos especiais preparados com ingredientes selecionados
        </p>
      </div>

      <div className="cardapio-container">
        <div className="categoria-tabs">
          {categorias.map((categoria) => (
            <button
              key={categoria.id}
              className={`categoria-tab ${categoriaAtiva === categoria.id ? 'active' : ''}`}
              onClick={() => setCategoriaAtiva(categoria.id)}
            >
              {categoria.label}
            </button>
          ))}
        </div>

        <div className="menu-items">
          {categoriaAtual?.items.map((item) => (
            <div key={item.id} className="menu-item">
              <div className="menu-item-header">
                <h3 className="menu-item-name">{item.nome}</h3>
                <span className="menu-item-price">R$ {item.preco.toFixed(2)}</span>
              </div>
              <p className="menu-item-description">{item.descricao}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Cardapio;
