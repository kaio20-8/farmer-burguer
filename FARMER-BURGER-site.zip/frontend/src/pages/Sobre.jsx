import React from 'react';
import { Award, Heart, Users, Flame } from 'lucide-react';
import '../styles/Sobre.css';

const Sobre = () => {
  return (
    <div className="sobre-page">
      <div className="page-hero">
        <h1 className="page-title">Sobre a Farmer Burger</h1>
        <p className="page-subtitle">
          Conheça nossa história, valores e paixão pela gastronomia
        </p>
      </div>

      <div className="sobre-container">
        {/* Nossa História */}
        <section className="sobre-section">
          <div className="sobre-content">
            <h2 className="sobre-title">Nossa História</h2>
            <div className="sobre-text-block">
              <p>
                A <strong>Farmer Burger</strong> nasceu da paixão por criar experiências gastronômicas únicas, 
                combinando a tradição da parrilla argentina com ingredientes brasileiros de alta qualidade.
              </p>
              <p>
                Desde o início, nosso compromisso foi trazer sabores autênticos e marcantes, preparados 
                com técnicas tradicionais e muito carinho. Cada prato é uma celebração do que há de melhor 
                na culinária, servido em um ambiente acolhedor e sofisticado.
              </p>
            </div>
          </div>
        </section>

        {/* Valores */}
        <section className="valores-section">
          <h2 className="valores-title">Nossos Valores</h2>
          <div className="valores-grid">
            <div className="valor-card">
              <div className="valor-icon">
                <Flame size={40} />
              </div>
              <h3>Paixão pela Gastronomia</h3>
              <p>
                Cada prato é preparado com dedicação e amor pela arte de cozinhar, 
                usando técnicas tradicionais da parrilla argentina.
              </p>
            </div>

            <div className="valor-card">
              <div className="valor-icon">
                <Award size={40} />
              </div>
              <h3>Qualidade Premium</h3>
              <p>
                Selecionamos criteriosamente cada ingrediente, priorizando frescor, 
                sabor e origem, garantindo excelência em cada refeição.
              </p>
            </div>

            <div className="valor-card">
              <div className="valor-icon">
                <Users size={40} />
              </div>
              <h3>Experiência Única</h3>
              <p>
                Oferecemos mais que uma refeição: criamos momentos memoráveis em um 
                ambiente acolhedor, com atendimento atencioso e personalizado.
              </p>
            </div>

            <div className="valor-card">
              <div className="valor-icon">
                <Heart size={40} />
              </div>
              <h3>Sabor Autêntico</h3>
              <p>
                Mantemos a essência dos sabores tradicionais enquanto inovamos com 
                criações exclusivas que surpreendem o paladar.
              </p>
            </div>
          </div>
        </section>

        {/* Diferenciais */}
        <section className="diferenciais-section">
          <h2 className="diferenciais-title">O Que Nos Torna Especiais</h2>
          <div className="diferenciais-list">
            <div className="diferencial-item">
              <div className="diferencial-number">01</div>
              <div className="diferencial-content">
                <h3>Parrilla Argentina Autêntica</h3>
                <p>
                  Nossas carnes são grelhadas em parrilla argentina tradicional, 
                  garantindo sabor defumado e textura perfeita.
                </p>
              </div>
            </div>

            <div className="diferencial-item">
              <div className="diferencial-number">02</div>
              <div className="diferencial-content">
                <h3>Ingredientes Locais e Frescos</h3>
                <p>
                  Trabalhamos com fornecedores regionais, valorizando produtos frescos 
                  e de qualidade superior em todos os nossos pratos.
                </p>
              </div>
            </div>

            <div className="diferencial-item">
              <div className="diferencial-number">03</div>
              <div className="diferencial-content">
                <h3>Receitas Exclusivas</h3>
                <p>
                  Nosso cardápio foi desenvolvido por chefs especializados, combinando 
                  técnicas clássicas com criações inovadoras.
                </p>
              </div>
            </div>

            <div className="diferencial-item">
              <div className="diferencial-number">04</div>
              <div className="diferencial-content">
                <h3>Ambiente Acolhedor</h3>
                <p>
                  Um espaço que une rusticidade e sofisticação, perfeito para 
                  momentos especiais com amigos e família.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="sobre-cta">
          <h2>Venha Conhecer!</h2>
          <p>
            Estamos ansiosos para receber você e proporcionar uma experiência gastronômica inesquecível. 
            Visite-nos e descubra por que somos referência em qualidade e sabor.
          </p>
        </section>
      </div>
    </div>
  );
};

export default Sobre;
