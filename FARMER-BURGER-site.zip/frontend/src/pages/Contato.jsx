import React, { useState } from 'react';
import { Phone, Instagram, Facebook, Send } from 'lucide-react';
import '../styles/Contato.css';

const Contato = () => {
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: '',
    mensagem: ''
  });

  const [enviado, setEnviado] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Simulando envio do formulário
    console.log('Form submitted:', formData);
    setEnviado(true);
    setTimeout(() => {
      setEnviado(false);
      setFormData({ nome: '', email: '', telefone: '', mensagem: '' });
    }, 3000);
  };

  const whatsappNumber = '5581999999999';
  const whatsappMessage = 'Olá! Gostaria de saber mais sobre a Farmer Burger.';
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(whatsappMessage)}`;

  return (
    <div className="contato-page">
      <div className="page-hero">
        <h1 className="page-title">Fale Conosco</h1>
        <p className="page-subtitle">
          Estamos prontos para atender você. Entre em contato!
        </p>
      </div>

      <div className="contato-container">
        <div className="contato-grid">
          {/* Formulário */}
          <div className="contato-form-section">
            <h2 className="contato-section-title">Envie sua Mensagem</h2>
            <p className="contato-section-text">
              Preencha o formulário abaixo e entraremos em contato o mais breve possível.
            </p>

            {enviado && (
              <div className="success-message">
                Mensagem enviada com sucesso! Entraremos em contato em breve.
              </div>
            )}

            <form onSubmit={handleSubmit} className="contato-form">
              <div className="form-group">
                <label htmlFor="nome" className="form-label">Nome Completo</label>
                <input
                  type="text"
                  id="nome"
                  name="nome"
                  value={formData.nome}
                  onChange={handleChange}
                  className="form-input"
                  required
                  placeholder="Seu nome"
                />
              </div>

              <div className="form-group">
                <label htmlFor="email" className="form-label">E-mail</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="form-input"
                  required
                  placeholder="seu@email.com"
                />
              </div>

              <div className="form-group">
                <label htmlFor="telefone" className="form-label">Telefone</label>
                <input
                  type="tel"
                  id="telefone"
                  name="telefone"
                  value={formData.telefone}
                  onChange={handleChange}
                  className="form-input"
                  placeholder="(81) 99999-9999"
                />
              </div>

              <div className="form-group">
                <label htmlFor="mensagem" className="form-label">Mensagem</label>
                <textarea
                  id="mensagem"
                  name="mensagem"
                  value={formData.mensagem}
                  onChange={handleChange}
                  className="form-textarea"
                  rows="5"
                  required
                  placeholder="Escreva sua mensagem aqui..."
                ></textarea>
              </div>

              <button type="submit" className="form-submit-btn">
                <Send size={20} />
                Enviar Mensagem
              </button>
            </form>
          </div>

          {/* Informações de Contato */}
          <div className="contato-info-section">
            <h2 className="contato-section-title">Outras Formas de Contato</h2>

            <div className="contact-methods">
              <div className="contact-method">
                <div className="contact-method-icon">
                  <Phone size={28} />
                </div>
                <div className="contact-method-content">
                  <h3>Telefone</h3>
                  <a href="tel:+5581999999999">(81) 99999-9999</a>
                  <p>Seg a Dom: 11:00 - 23:00</p>
                </div>
              </div>

              <div className="contact-method whatsapp">
                <div className="contact-method-icon">
                  <Phone size={28} />
                </div>
                <div className="contact-method-content">
                  <h3>WhatsApp</h3>
                  <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
                    Falar no WhatsApp
                  </a>
                  <p>Resposta rápida garantida</p>
                </div>
              </div>

              <div className="contact-method">
                <div className="contact-method-icon social">
                  <Instagram size={28} />
                </div>
                <div className="contact-method-content">
                  <h3>Instagram</h3>
                  <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
                    @farmerburger
                  </a>
                  <p>Acompanhe nossas novidades</p>
                </div>
              </div>

              <div className="contact-method">
                <div className="contact-method-icon social">
                  <Facebook size={28} />
                </div>
                <div className="contact-method-content">
                  <h3>Facebook</h3>
                  <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">
                    Farmer Burger
                  </a>
                  <p>Curta nossa página</p>
                </div>
              </div>
            </div>

            <div className="cta-whatsapp">
              <h3>Preferência Imediata?</h3>
              <p>Entre em contato via WhatsApp para reservas e informações rápidas.</p>
              <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="whatsapp-btn">
                <Phone size={20} />
                Chamar no WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contato;
