import React from 'react';
import { Link } from 'react-router-dom';
import { ChefHat, Flame, Award } from 'lucide-react';
import { destaquesPratos } from '../data/mock';
import '../styles/Home.css';

const Home = () => {
  return (
    <div className="home">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-overlay"></div>
        <div className="hero-content">
          <h1 className="hero-title">
            FARMER BURGER
          </h1>
          <p className="hero-subtitle">
            Onde o sabor encontra a tradição
          </p>
          <p className="hero-description">
            Experimente o autêntico sabor da parrilla argentina com ingredientes premium e receitas exclusivas
          </p>
          <Link to="/cardapio" className="hero-btn">
            VER CARDÁPIO
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <div className="features-container">
          <div className="feature-card">
            <div className="feature-icon">
              <ChefHat size={40} />
            </div>
            <h3 className="feature-title">Receitas Exclusivas</h3>
            <p className="feature-text">
              Pratos elaborados por chefs especializados com técnicas da parrilla argentina
            </p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">
              <Flame size={40} />
            </div>
            <h3 className="feature-title">Grelhados na Parrilla</h3>
            <p className="feature-text">
              Carnes selecionadas preparadas em parrilla argentina para sabor incomparável
            </p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">
              <Award size={40} />
            </div>
            <h3 className="feature-title">Ingredientes Premium</h3>
            <p className="feature-text">
              Seleção criteriosa de ingredientes frescos e de alta qualidade
            </p>
          </div>
        </div>
      </section>

      {/* Popular Dishes Section */}
      <section className="popular-section">
        <div className="section-header">
          <h2 className="section-title">Mais Pedidos</h2>
          <p className="section-subtitle">Conheça os favoritos dos nossos clientes</p>
        </div>

        <div className="dishes-grid">
          {destaquesPratos.slice(0, 3).map((prato) => (
            <div key={prato.id} className="dish-card">
              <div className="dish-image-placeholder">
                <ChefHat size={48} className="placeholder-icon" />
              </div>
              <div className="dish-content">
                <h3 className="dish-name">{prato.nome}</h3>
                <p className="dish-description">{prato.descricao}</p>
                <div className="dish-footer">
                  <span className="dish-price">R$ {prato.preco.toFixed(2)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="section-cta">
          <Link to="/destaques" className="cta-btn">
            VER TODOS OS DESTAQUES
          </Link>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="cta-section">
        <div className="cta-content">
          <h2 className="cta-title">Visite Nosso Restaurante</h2>
          <p className="cta-text">
            Venha experimentar uma experiência gastronômica única em um ambiente acolhedor e sofisticado
          </p>
          <div className="cta-buttons">
            <Link to="/localizacao" className="cta-primary-btn">
              LOCALIZAÇÃO & HORÁRIOS
            </Link>
            <Link to="/contato" className="cta-secondary-btn">
              FALE CONOSCO
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
