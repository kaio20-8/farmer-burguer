import React from 'react';
import { almocoExecutivo } from '../data/mock';
import { Clock, Utensils } from 'lucide-react';
import '../styles/AlmocoExecutivo.css';

const AlmocoExecutivo = () => {
  return (
    <div className="almoco-page">
      <div className="page-hero">
        <h1 className="page-title">Almoço Executivo</h1>
        <p className="page-subtitle">
          Opções completas e deliciosas para o seu almoço
        </p>
      </div>

      <div className="almoco-info">
        <div className="info-card">
          <Clock size={32} />
          <div>
            <h3>Horário de Almoço</h3>
            <p>Segunda a Sexta: 11:00 - 15:00</p>
          </div>
        </div>
        <div className="info-card">
          <Utensils size={32} />
          <div>
            <h3>Pratos Completos</h3>
            <p>Com acompanhamentos inclusos</p>
          </div>
        </div>
      </div>

      <div className="almoco-container">
        <div className="almoco-grid">
          {almocoExecutivo.map((prato) => (
            <div key={prato.id} className="almoco-card">
              <div className="almoco-card-header">
                <h3 className="almoco-nome">{prato.nome}</h3>
                <span className="almoco-preco">R$ {prato.preco.toFixed(2)}</span>
              </div>
              <p className="almoco-descricao">{prato.descricao}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AlmocoExecutivo;
