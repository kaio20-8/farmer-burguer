import React from 'react';
import { MapPin, Clock, Phone, Navigation } from 'lucide-react';
import '../styles/Localizacao.css';

const Localizacao = () => {
  const endereco = "R. Almirante Tamandaré, 102, Centro - São Lourenço da Mata - PE, CEP: 54735-420";
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(endereco)}`;

  return (
    <div className="localizacao-page">
      <div className="page-hero">
        <h1 className="page-title">Localização & Horários</h1>
        <p className="page-subtitle">
          Visite-nos e experimente o melhor da gastronomia
        </p>
      </div>

      <div className="localizacao-container">
        <div className="localizacao-grid">
          {/* Endereço */}
          <div className="info-box">
            <div className="info-box-icon">
              <MapPin size={32} />
            </div>
            <h3 className="info-box-title">Endereço</h3>
            <p className="info-box-text">
              R. Almirante Tamandaré, 102<br />
              Centro - São Lourenço da Mata - PE<br />
              CEP: 54735-420
            </p>
            <a 
              href={mapsUrl}
              target="_blank" 
              rel="noopener noreferrer" 
              className="info-box-btn"
            >
              <Navigation size={18} />
              Abrir no Google Maps
            </a>
          </div>

          {/* Horários */}
          <div className="info-box">
            <div className="info-box-icon">
              <Clock size={32} />
            </div>
            <h3 className="info-box-title">Horário de Funcionamento</h3>
            <div className="horarios-list">
              <div className="horario-item">
                <span className="horario-dia">Segunda a Quarta</span>
                <span className="horario-hora">11:00 - 23:00</span>
              </div>
              <div className="horario-item">
                <span className="horario-dia">Quinta-feira</span>
                <span className="horario-hora">11:00 - 23:00</span>
              </div>
              <div className="horario-item highlight">
                <span className="horario-dia">Sexta-feira</span>
                <span className="horario-hora">11:00 - 02:00</span>
              </div>
              <div className="horario-item">
                <span className="horario-dia">Sábado</span>
                <span className="horario-hora">11:00 - 23:00</span>
              </div>
              <div className="horario-item">
                <span className="horario-dia">Domingo</span>
                <span className="horario-hora">11:00 - 23:00</span>
              </div>
            </div>
          </div>

          {/* Contato */}
          <div className="info-box">
            <div className="info-box-icon">
              <Phone size={32} />
            </div>
            <h3 className="info-box-title">Telefone</h3>
            <p className="info-box-text">
              Entre em contato conosco para reservas ou informações:
            </p>
            <a href="tel:+5581999999999" className="info-box-phone">
              (81) 99999-9999
            </a>
          </div>
        </div>

        {/* Map Placeholder */}
        <div className="map-section">
          <div className="map-placeholder">
            <MapPin size={64} />
            <p>Mapa de Localização</p>
            <a 
              href={mapsUrl}
              target="_blank" 
              rel="noopener noreferrer" 
              className="map-btn"
            >
              Ver no Google Maps
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Localizacao;
