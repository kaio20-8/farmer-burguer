import React from 'react';
import { destaquesPratos, destaquesSobremesas, destaquesBebidas } from '../data/mock';
import { Star } from 'lucide-react';
import '../styles/Destaques.css';

const Destaques = () => {
  return (
    <div className="destaques-page">
      <div className="page-hero">
        <h1 className="page-title">Destaques & Mais Pedidos</h1>
        <p className="page-subtitle">
          Os favoritos dos nossos clientes que você não pode deixar de experimentar
        </p>
      </div>

      <div className="destaques-container">
        {/* Pratos Principais */}
        <section className="destaques-section">
          <div className="section-header-destaques">
            <Star className="section-icon" size={32} />
            <h2 className="section-title-destaques">Pratos Principais</h2>
          </div>
          <div className="destaques-grid">
            {destaquesPratos.map((item) => (
              <div key={item.id} className="destaque-card">
                <div className="destaque-badge">
                  <Star size={16} />
                  <span>Mais Pedido</span>
                </div>
                <h3 className="destaque-nome">{item.nome}</h3>
                <p className="destaque-categoria">{item.categoria}</p>
                <p className="destaque-descricao">{item.descricao}</p>
                <div className="destaque-footer">
                  <span className="destaque-preco">R$ {item.preco.toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Sobremesas */}
        <section className="destaques-section">
          <div className="section-header-destaques">
            <Star className="section-icon" size={32} />
            <h2 className="section-title-destaques">Sobremesas</h2>
          </div>
          <div className="destaques-grid">
            {destaquesSobremesas.map((item) => (
              <div key={item.id} className="destaque-card">
                <div className="destaque-badge sobremesa">
                  <Star size={16} />
                  <span>Irresistível</span>
                </div>
                <h3 className="destaque-nome">{item.nome}</h3>
                <p className="destaque-categoria">{item.categoria}</p>
                <p className="destaque-descricao">{item.descricao}</p>
                <div className="destaque-footer">
                  <span className="destaque-preco">R$ {item.preco.toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Bebidas */}
        <section className="destaques-section">
          <div className="section-header-destaques">
            <Star className="section-icon" size={32} />
            <h2 className="section-title-destaques">Bebidas & Entradas</h2>
          </div>
          <div className="destaques-grid">
            {destaquesBebidas.map((item) => (
              <div key={item.id} className="destaque-card">
                <div className="destaque-badge bebida">
                  <Star size={16} />
                  <span>Refrescante</span>
                </div>
                <h3 className="destaque-nome">{item.nome}</h3>
                <p className="destaque-categoria">{item.categoria}</p>
                <p className="destaque-descricao">{item.descricao}</p>
                <div className="destaque-footer">
                  <span className="destaque-preco">R$ {item.preco.toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Destaques;
