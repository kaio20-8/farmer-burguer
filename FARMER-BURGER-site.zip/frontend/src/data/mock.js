// Mock data for Farmer Burger

export const almocoExecutivo = [
  {
    id: 1,
    nome: "PARMEGIANA DE FRANGO",
    descricao: "Filé de peito de frango empanado, molho de tomate da casa, queijo muçarela, batata frita e espaguete ao molho de tomate finalizado com parmesão ralado.",
    preco: 16.99
  },
  {
    id: 2,
    nome: "COSTELA BOVINA NO BAFO COM LINGUIÇA TOSCANA",
    descricao: "Costela bovina no bafo finalizada na parrilla argentina, linguiça toscana grelhada, feijão preto ou feijão de corda, arroz branco, farofa da casa e vinagrete.",
    preco: 16.99
  },
  {
    id: 3,
    nome: "PICANHA ARGENTINA",
    descricao: "Corte argentino grelhado na parrilla, baião de dois ao queijo ou feijão de corda com arroz branco, batata frita, farofa da casa e vinagrete.",
    preco: 34.99
  },
  {
    id: 4,
    nome: "COSTELINHA SUÍNA AO MOLHO BARBECUE",
    descricao: "Costelinha suína regada ao molho barbecue, arroz biru-biru e batata palha.",
    preco: 19.90
  },
  {
    id: 5,
    nome: "SOBRECOXA DE FRANGO COM LINGUIÇA TOSCANA",
    descricao: "Sobrecoxa marinada no dry rub, grelhada na parrilla argentina, linguiça toscana, feijão, arroz, farofa e vinagrete.",
    preco: 14.99
  },
  {
    id: 6,
    nome: "CALDEIRADA",
    descricao: "Seleção de frutos do mar ao molho de coco, pirão, arroz branco e farinha baiana.",
    preco: 24.99
  },
  {
    id: 7,
    nome: "PRIME RIB DE CORDEIRO",
    descricao: "Costela de cordeiro grelhada na parrilla, baião de dois ao queijo ou feijão de corda, batata frita, farofa e vinagrete.",
    preco: 24.99
  },
  {
    id: 8,
    nome: "CUPIM NO BAFO",
    descricao: "Cupim macio e suculento no bafo, finalizado na parrilla, linguiça toscana, feijão, arroz, farofa e vinagrete.",
    preco: 16.99
  }
];

export const destaquesPratos = [
  {
    id: 1,
    nome: "Hambúrguer de Carne Seca",
    categoria: "Hambúrguers",
    descricao: "Suculento hambúrguer com carne seca desfiada, queijo coalho e maionese temperada",
    preco: 28.90
  },
  {
    id: 2,
    nome: "Duplo Sertanejo",
    categoria: "Hambúrguers",
    descricao: "Dois hambúrgueres artesanais, queijo coalho, bacon crocante e molho especial",
    preco: 32.90
  },
  {
    id: 3,
    nome: "Delícia Pernambucana",
    categoria: "Hambúrguers",
    descricao: "Hambúrguer premium com ingredientes da culinária pernambucana",
    preco: 29.90
  },
  {
    id: 4,
    nome: "Camarão Prime",
    categoria: "Frutos do Mar",
    descricao: "Camarões grandes e suculentos ao molho especial da casa",
    preco: 45.90
  },
  {
    id: 5,
    nome: "Camarão na Taça",
    categoria: "Frutos do Mar",
    descricao: "Camarões empanados servidos em taça com molhos variados",
    preco: 38.90
  },
  {
    id: 6,
    nome: "Camarão ao Alho e Óleo",
    categoria: "Frutos do Mar",
    descricao: "Camarões salteados no alho e óleo, acompanhados de torradas",
    preco: 42.90
  },
  {
    id: 7,
    nome: "Batata Frita com Cheddar e Bacon",
    categoria: "Acompanhamentos",
    descricao: "Porção generosa de batatas fritas cobertas com cheddar cremoso e bacon",
    preco: 22.90
  }
];

export const destaquesSobremesas = [
  {
    id: 1,
    nome: "Torre de Brownie com Sorvete",
    categoria: "Sobremesas",
    descricao: "Torre de brownies intercalados com sorvete e calda quente",
    preco: 24.90
  },
  {
    id: 2,
    nome: "Petit Gateau",
    categoria: "Sobremesas",
    descricao: "Bolinho de chocolate quente com recheio cremoso e sorvete",
    preco: 18.90
  },
  {
    id: 3,
    nome: "Mini Torre dos Desejos",
    categoria: "Sobremesas",
    descricao: "Versão mini da nossa famosa torre com diversos sabores",
    preco: 19.90
  },
  {
    id: 4,
    nome: "Tacinha dos Sonhos",
    categoria: "Sobremesas",
    descricao: "Taça com camadas de doce de leite, creme e biscoitos",
    preco: 16.90
  }
];

export const destaquesBebidas = [
  {
    id: 1,
    nome: "Milkshake de Morango",
    categoria: "Bebidas",
    descricao: "Milkshake cremoso com morangos frescos",
    preco: 14.90
  },
  {
    id: 2,
    nome: "Farmer Frutas Vermelhas",
    categoria: "Bebidas",
    descricao: "Drink especial com mix de frutas vermelhas",
    preco: 16.90
  },
  {
    id: 3,
    nome: "Caldinho de Feijão",
    categoria: "Entradas",
    descricao: "Caldinho cremoso servido com torradas",
    preco: 8.90
  },
  {
    id: 4,
    nome: "Caldinho de Camarão",
    categoria: "Entradas",
    descricao: "Caldinho de camarão temperado servido com torradas",
    preco: 12.90
  },
  {
    id: 5,
    nome: "Drink Lagoa Azul",
    categoria: "Drinks",
    descricao: "Drink refrescante com toque cítrico",
    preco: 15.90
  },
  {
    id: 6,
    nome: "Drink de Limão Siciliano",
    categoria: "Drinks",
    descricao: "Drink com limão siciliano e toque especial",
    preco: 14.90
  },
  {
    id: 7,
    nome: "Heineken",
    categoria: "Cervejas",
    descricao: "Cerveja Heineken long neck gelada",
    preco: 9.90
  },
  {
    id: 8,
    nome: "Suco de Kiwi",
    categoria: "Sucos",
    descricao: "Suco natural de kiwi",
    preco: 10.90
  }
];

export const cardapioCompleto = {
  hamburguers: [
    {
      id: 1,
      nome: "Classic Farmer",
      descricao: "180g de blend artesanal, queijo cheddar, alface, tomate e molho especial",
      preco: 24.90
    },
    {
      id: 2,
      nome: "Hambúrguer de Carne Seca",
      descricao: "Suculento hambúrguer com carne seca desfiada, queijo coalho e maionese temperada",
      preco: 28.90
    },
    {
      id: 3,
      nome: "Duplo Sertanejo",
      descricao: "Dois hambúrgueres artesanais, queijo coalho, bacon crocante e molho especial",
      preco: 32.90
    },
    {
      id: 4,
      nome: "Delícia Pernambucana",
      descricao: "Hambúrguer premium com ingredientes da culinária pernambucana",
      preco: 29.90
    },
    {
      id: 5,
      nome: "Bacon Supreme",
      descricao: "180g de carne, bacon crocante, cebola caramelizada e molho barbecue",
      preco: 27.90
    }
  ],
  carnes: [
    {
      id: 1,
      nome: "Picanha Argentina",
      descricao: "Corte argentino grelhado na parrilla, baião de dois ao queijo ou feijão de corda com arroz branco, batata frita, farofa da casa e vinagrete",
      preco: 34.99
    },
    {
      id: 2,
      nome: "Costela Bovina no Bafo",
      descricao: "Costela macia finalizada na parrilla, acompanhada de feijão, arroz e farofa",
      preco: 16.99
    },
    {
      id: 3,
      nome: "Prime Rib de Cordeiro",
      descricao: "Costela de cordeiro grelhada, acompanhamentos especiais",
      preco: 24.99
    }
  ],
  frutosDoMar: [
    {
      id: 1,
      nome: "Camarão Prime",
      descricao: "Camarões grandes e suculentos ao molho especial da casa",
      preco: 45.90
    },
    {
      id: 2,
      nome: "Camarão na Taça",
      descricao: "Camarões empanados servidos em taça com molhos variados",
      preco: 38.90
    },
    {
      id: 3,
      nome: "Camarão ao Alho e Óleo",
      descricao: "Camarões salteados no alho e óleo, acompanhados de torradas",
      preco: 42.90
    },
    {
      id: 4,
      nome: "Caldeirada",
      descricao: "Seleção de frutos do mar ao molho de coco, pirão, arroz branco e farinha baiana",
      preco: 24.99
    }
  ],
  acompanhamentos: [
    {
      id: 1,
      nome: "Batata Frita com Cheddar e Bacon",
      descricao: "Porção generosa de batatas fritas cobertas com cheddar cremoso e bacon",
      preco: 22.90
    },
    {
      id: 2,
      nome: "Onion Rings",
      descricao: "Anéis de cebola empanados e crocantes",
      preco: 16.90
    },
    {
      id: 3,
      nome: "Batata Rústica",
      descricao: "Batatas rústicas temperadas com ervas",
      preco: 14.90
    }
  ],
  sobremesas: [
    {
      id: 1,
      nome: "Torre de Brownie com Sorvete",
      descricao: "Torre de brownies intercalados com sorvete e calda quente",
      preco: 24.90
    },
    {
      id: 2,
      nome: "Petit Gateau",
      descricao: "Bolinho de chocolate quente com recheio cremoso e sorvete",
      preco: 18.90
    },
    {
      id: 3,
      nome: "Mini Torre dos Desejos",
      descricao: "Versão mini da nossa famosa torre com diversos sabores",
      preco: 19.90
    },
    {
      id: 4,
      nome: "Tacinha dos Sonhos",
      descricao: "Taça com camadas de doce de leite, creme e biscoitos",
      preco: 16.90
    }
  ],
  bebidas: [
    {
      id: 1,
      nome: "Milkshake de Morango",
      descricao: "Milkshake cremoso com morangos frescos",
      preco: 14.90
    },
    {
      id: 2,
      nome: "Farmer Frutas Vermelhas",
      descricao: "Drink especial com mix de frutas vermelhas",
      preco: 16.90
    },
    {
      id: 3,
      nome: "Drink Lagoa Azul",
      descricao: "Drink refrescante com toque cítrico",
      preco: 15.90
    },
    {
      id: 4,
      nome: "Drink de Limão Siciliano",
      descricao: "Drink com limão siciliano e toque especial",
      preco: 14.90
    },
    {
      id: 5,
      nome: "Heineken",
      descricao: "Cerveja Heineken long neck gelada",
      preco: 9.90
    },
    {
      id: 6,
      nome: "Suco de Kiwi",
      descricao: "Suco natural de kiwi",
      preco: 10.90
    }
  ]
};
