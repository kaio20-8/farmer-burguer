import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Cardapio from './pages/Cardapio';
import AlmocoExecutivo from './pages/AlmocoExecutivo';
import Destaques from './pages/Destaques';
import Sobre from './pages/Sobre';
import Localizacao from './pages/Localizacao';
import Contato from './pages/Contato';
import './App.css';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cardapio" element={<Cardapio />} />
          <Route path="/almoco-executivo" element={<AlmocoExecutivo />} />
          <Route path="/destaques" element={<Destaques />} />
          <Route path="/sobre" element={<Sobre />} />
          <Route path="/localizacao" element={<Localizacao />} />
          <Route path="/contato" element={<Contato />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
