import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Clock, Phone, Instagram, Facebook } from 'lucide-react';
import '../styles/Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-section">
          <h3 className="footer-title">FARMER BURGER</h3>
          <p className="footer-text">
            Experiência gastronômica premium com sabor autêntico e ingredientes selecionados.
          </p>
        </div>

        <div className="footer-section">
          <h4 className="footer-subtitle">Links Rápidos</h4>
          <div className="footer-links">
            <Link to="/cardapio" className="footer-link">Cardápio</Link>
            <Link to="/almoco-executivo" className="footer-link">Almoço Executivo</Link>
            <Link to="/destaques" className="footer-link">Destaques</Link>
            <Link to="/sobre" className="footer-link">Sobre Nós</Link>
          </div>
        </div>

        <div className="footer-section">
          <h4 className="footer-subtitle">Contato</h4>
          <div className="footer-info">
            <div className="info-item">
              <MapPin size={18} />
              <span>R. Almirante Tamandaré, 102<br />Centro - São Lourenço da Mata - PE</span>
            </div>
            <div className="info-item">
              <Phone size={18} />
              <span>(81) 99999-9999</span>
            </div>
          </div>
        </div>

        <div className="footer-section">
          <h4 className="footer-subtitle">Horário de Funcionamento</h4>
          <div className="footer-info">
            <div className="info-item">
              <Clock size={18} />
              <div>
                <p>Seg - Qui: 11:00 - 23:00</p>
                <p>Sex: 11:00 - 02:00</p>
                <p>Sáb - Dom: 11:00 - 23:00</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <div className="footer-container">
          <div className="social-links">
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="social-icon">
              <Instagram size={20} />
            </a>
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="social-icon">
              <Facebook size={20} />
            </a>
          </div>
          <p className="copyright">
            © {new Date().getFullYear()} Farmer Burger. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
